/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pa.cifpaviles.dam.aeropuerto.logica;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import javax.swing.text.EditorKit;
import javax.xml.stream.events.Comment;
import pa.cifpaviles.dam.aeropuerto.dto.Aeropuerto;
import pa.cifpaviles.dam.aeropuerto.dto.Companya;
import pa.cifpaviles.dam.aeropuerto.dto.Municipio;
import pa.cifpaviles.dam.aeropuerto.dto.VueloBase;
import pa.cifpaviles.dam.aeropuerto.dto.VueloDiario;

/**
 *
 * @author javierig
 */
public class LogicaNegocio {

    //Inicializacion de variables
    public static void initializeProgram() {
        initializeMunicipios();
        initializeAeropuerto();
        initializeCompanyas();
    }
    private static List<Municipio> lstMunicipios = new  ArrayList<>();
    private static void initializeMunicipios() {
        lstMunicipios.add(new Municipio("02003","Albacete"));
        lstMunicipios.add(new Municipio("33044","Oviedo"));
        lstMunicipios.add(new Municipio("33016","Castrillón"));
        lstMunicipios.add(new Municipio("24139","Valverde de la Virgen"));
        lstMunicipios.add(new Municipio("24089","León"));
        //lstMunicipios.add(new Municipio("28079","Madrid"));
    }
    
    public static List<Municipio> getAllMunicipios(){
        return lstMunicipios;
    }

    //<editor-fold desc="Lógica de aeropuertos"> 
    public static void initializeAeropuerto() {
        addAeropuerto(new Aeropuerto("ABC", "Aeropuerto de Albacete", "02003"));
        addAeropuerto(new Aeropuerto("OVD", "Aeropuerto de Asturias", "33016"));
        addAeropuerto(new Aeropuerto("LEN", "Aeropuerto de León", "24189"));
        addAeropuerto(new Aeropuerto("OSL", "Aeropuerto de Oslo-Gardermoen", "00000"));
    }

    private static List<Aeropuerto> lstAeropuertos = new ArrayList<Aeropuerto>();

    /**
     * Añade un aeropuerto a su colección
     *
     * @param aero
     */
    public static ValidationResult addAeropuerto(Aeropuerto aero) {
        ValidationResult retValue = new ValidationResult(true, "");
        Aeropuerto aux = getAeropuertoByCodigoIATA(aero.getCodigoIATA());
        if (aux == null) {
            lstAeropuertos.add(aero);
        } else {
            retValue = new ValidationResult(false, "El código IATA del aeropuerto ya existe.No se añadirá a la lista.");
        }
        return retValue;
    }

    public static List<Aeropuerto> getAllAeropuertos() {
        return lstAeropuertos;
    }

    public static Aeropuerto getAeropuertoByCodigoIATA(String codigoIATA) {

        for (Aeropuerto a : lstAeropuertos) {
            if (a.getCodigoIATA().equals(codigoIATA)) {
                return a;
            }
        }
        return null;
    }

    public static Aeropuerto getAeropuertoBase() {
        return getAeropuertoByCodigoIATA("OVD");
    }

    //</editor-fold>
    
    //<editor-fold desc="Lógica de compañias">
    private static List<Companya> lstCompanyas = new ArrayList<Companya>();
    private static void initializeCompanyas() {
        Companya c1 = new Companya(75,
                "IB",
                "Iberia Líneas Aéreas de España",
                "C/ Marqués s/n",
                "28079",
                "91-345-32-11",
                "900 100 192");

        addCompanya(c1);

        Companya c2 = new Companya(751,
                "VY",
                "Vueling",
                "Pº Castellana",
                "28079",
                "91-345-32-11",
                "900 100 192");

        addCompanya(c2);

        Companya c3 = new Companya(752,
                "V7",
                "Volotea",
                "C/ Verano Azul",
                "28079",
                "956-345-32-11",
                "923 100 192");

        addCompanya(c3);

    }

    public static List<Companya> getAllCompanyas() {
        return lstCompanyas;
    }

    public static Companya getCompanyaByPrefijo(int prefijo) {
        for (Companya c : lstCompanyas) {
            if (c.getPrefijo() == prefijo) {
                return c;
            }
        }
        return null;
    }

    public static Companya getCompanyaByCodigo(String codigo) {
        Optional<Companya> optValorSalida = lstCompanyas.stream()
                .filter(value -> value.getCodigo().equals(codigo))
                .findFirst();
        if (optValorSalida.isPresent()) {
            return optValorSalida.get();
        } else {
            return null;
        }
    }

    public static List<Companya> getCompanyasByMunicipio(String municipio) {
        return lstCompanyas.stream()
                .filter(value -> value.getMunicipio().equals(municipio))
                .toList();
    }

    public static ValidationResult addCompanya(Companya newComp) {
        ValidationResult retValue = new ValidationResult(true, "");
        Companya aux = getCompanyaByCodigo(newComp.getCodigo());
        if (aux == null) {
            lstCompanyas.add(newComp);
        } else {
            retValue = new ValidationResult(false, "El código de la compañia ya existe.No se añadirá a la lista.");
        }
        return retValue;
    }

    public static void updateCompanyaByCodigo(String codigo, Companya newComp) {
        Companya oldComp = getCompanyaByCodigo(codigo);
        if (oldComp != null) {
            oldComp.setDireccion(newComp.getDireccion());
            oldComp.setMunicipio(newComp.getMunicipio());
            oldComp.setNombre(newComp.getNombre());
            oldComp.setPrefijo(newComp.getPrefijo());
            oldComp.setTelefonoInformacion(newComp.getTelefonoInformacion());
            oldComp.setTelefonoPasajeros(newComp.getTelefonoPasajeros());
        }
    }

    public static void deleteCompanyaByCodigo(String codigo) {
        Companya delComp = getCompanyaByCodigo(codigo);
        if (delComp != null) {
            lstCompanyas.remove(delComp);
        }
    }

    // </editor-fold>
    
    //<editor-fold desc="Lógica de vuelos base">  
    private static List<VueloBase> lstVuelosBase = new ArrayList<VueloBase>();

    public static List<VueloBase> getAllVuelosBase() {
        return new ArrayList<VueloBase>();
    }

    public static ValidationResult addVueloBase(VueloBase vuelo) {
        ValidationResult retValue = new ValidationResult(true, "");
        VueloBase aux = getVueloBaseByCodigo(vuelo.getCodigoVuelo());
        if (aux == null) {
            lstVuelosBase.add(vuelo);
        } else {
            retValue = new ValidationResult(false, "El vuelo base ya existe.No se añadirá a la lista.");
        }
        return retValue;
    }

    public static VueloBase getVueloBaseByCodigo(String codigo) {
        Optional<VueloBase> optValorSalida = lstVuelosBase.stream().filter(value -> value.getCodigoVuelo().equals(codigo)).findFirst();
        if (optValorSalida.isPresent()) {
            return optValorSalida.get();
        } else {
            return null;
        }
    }

    public static List<VueloBase> getVueloBasesByFecha(Date fecha) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(fecha);
        int diaSemana = cal.get(Calendar.DAY_OF_WEEK);
        String diaSemanaCad = "";
        switch (diaSemana) {
            case Calendar.SUNDAY:
                diaSemanaCad = "D";
                break;
            case Calendar.MONDAY:
                diaSemanaCad = "L";
                break;
            case Calendar.TUESDAY:
                diaSemanaCad = "M";
                break;
            case Calendar.WEDNESDAY:
                diaSemanaCad = "X";
                break;
            case Calendar.THURSDAY:
                diaSemanaCad = "J";
                break;
            case Calendar.FRIDAY:
                diaSemanaCad = "V";
                break;
            case Calendar.SATURDAY:
                diaSemanaCad = "S";
                break;
            default:
                diaSemanaCad = "";
        }
        return getVueloBaseByDiaSemana(diaSemanaCad);
    }

    public static List<VueloBase> getVueloBaseByDiaSemana(String diaSemana) {
        List<VueloBase> lstVueloByDiaSemana = (List<VueloBase>) lstVuelosBase.stream()
                .filter(v -> v.getDiasOperacion()
                .contains(diaSemana))
                .toList();
        return lstVueloByDiaSemana;
    }

    public static List<VueloBase> getVueloBaseByAeropuertoOrigen(String codigoIATA) {
        //List<VueloBase> lstVuelosByAeropuertoOrigen
         return lstVuelosBase.stream()
                .filter(v -> v.getCodigoAeropuertoOrigen().equals(codigoIATA))
                .toList();
    }

    public static List<VueloBase> getVueloBaseByAeropuretoDestino(String codigoIATA) {
        return lstVuelosBase.stream()
                .filter(v -> v.getCodigoAeropuertoDestino().equals(codigoIATA))
                .toList();
    }
    
    public static void updateVueloBaseByCodigo(String codigo, VueloBase newVuelo) {
        VueloBase oldVuelo = getVueloBaseByCodigo(codigo);
        if (oldVuelo != null) {
            oldVuelo.setAeropuertoDestino(newVuelo.getAeropuertoDestino());
            oldVuelo.setAeropuertoOrigen(newVuelo.getAeropuertoOrigen());
            oldVuelo.setDiasOperacion(newVuelo.getDiasOperacion());
            oldVuelo.setHoraLlegada(newVuelo.getHoraLlegada());
            oldVuelo.setHoraSalida(newVuelo.getHoraSalida());
            oldVuelo.setNumeroPlazas(newVuelo.getNumeroPlazas());
        }
    }
    
     public static void deleteVueloBaseByCodigo(String codigo) {
        VueloBase delVuelo = getVueloBaseByCodigo(codigo);
        if (delVuelo != null)
            lstVuelosBase.remove(delVuelo);
     }

    //</editor-fold>
    
    //<editor-fold desc="Lógica de vuelos diarios">  
    private static List<VueloDiario> lstVuelosDiarios = new ArrayList<VueloDiario>();

    public static List<VueloDiario> getAllVuelosDiarios() {
        return new ArrayList<VueloDiario>();
    }

    public static VueloDiario getVueloDiaropByCodigoVueloBase(String codigo) {
        return new VueloDiario();
    }

    public static VueloDiario getVueloDiarioByFecha(Date fecha) {
        return new VueloDiario();
    }

    public static Date getFechaByHora(int horas, int minutos) {
        Calendar cal = Calendar.getInstance();
        cal.set(1970, 1, 1, horas, minutos);
        Date fecha = cal.getTime();
        return fecha;
    }

    public static String getHoraFecha(Date fecha) {
        SimpleDateFormat adf = new SimpleDateFormat("HH:mm");
        return adf.format(fecha);
    }

    //</editor-fold>

    
}
