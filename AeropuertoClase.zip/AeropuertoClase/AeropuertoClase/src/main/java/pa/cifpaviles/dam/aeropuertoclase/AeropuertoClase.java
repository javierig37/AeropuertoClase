/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pa.cifpaviles.dam.aeropuertoclase;

import java.util.Date;
import java.util.List;
import pa.cifpaviles.dam.aeropuerto.dto.Aeropuerto;
import pa.cifpaviles.dam.aeropuerto.dto.Companya;
import pa.cifpaviles.dam.aeropuerto.dto.VueloBase;
import pa.cifpaviles.dam.aeropuerto.logica.LogicaNegocio;

/**
 *
 * @author javierig
 */
public class AeropuertoClase {

    public static void main(String[] args) {
        LogicaNegocio.initializeProgram();
        Aeropuerto aeropuertoBase = LogicaNegocio.getAeropuertoBase();
        

        
        List<Companya> lista = LogicaNegocio.getAllCompanyas();
        List<Companya> compMadrid = LogicaNegocio.getCompanyasByMunicipio("28079");
        LogicaNegocio.addVueloBase
        (new VueloBase("IB123", 3,
                new Date(), 
                new Date(), 
                "LMV", 
                aeropuertoBase.getCodigoIATA(), 
                "ABC"));
        Date fechaActual = new Date();
        List<VueloBase> vuelos = LogicaNegocio.getVueloBasesByFecha(fechaActual);
        String horaCadena = LogicaNegocio.getHoraFecha(fechaActual);
       
    }
}
